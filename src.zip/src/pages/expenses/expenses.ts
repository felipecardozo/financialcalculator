import { Component } from '@angular/core';

import { NavController } from 'ionic-angular';

import { FinancialService } from '../../app/services/financial.service';

@Component({
  selector: 'expenses',
  templateUrl: 'expenses.html'
})
export class ExpensesPage {

  idAccount:any;

  constructor(public navCtrl: NavController, private financialService:FinancialService) {
    console.log(financialService.getIdAccount());
  }

}
