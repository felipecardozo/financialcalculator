import {Injectable} from '@angular/core';
import { Expenses } from '../domain/expenses.domain';

@Injectable()
export class FinancialService{

    idAccount:String;
    expenses: Array<Expenses>;

    constructor(){
        this.idAccount = "";
    }

    setIdAccount( idAccount: String ){
        this.idAccount = idAccount;
    }

    getIdAccount(){
        return this.idAccount;
    }

    addExpense( detail:String, value:number ){
        let expense : Expenses;
        expense.setDetailValue(detail, value);
        this.expenses.push( expense );
    }

    printExpenses(){
        console.log(this.expenses);
    }

    removeExpense( idExpense:number ){
        //TODO implement
    }

}