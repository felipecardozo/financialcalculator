import {Injectable} from '@angular/core';

@Injectable()
export class Expenses{

    detail:String;
    value: number;
    
    constructor(){
    }

    setDetail( detail:String ){
        this.detail = detail;
    }

    getDetail(){
        return this.detail;
    }

    setValue(value: number){
        this.value = value;
    }

    getValue(){
        return this.value;
    }

    setDetailValue( detail:String, value:number ){
        this.detail = detail;
        this.value = value;
    }

}